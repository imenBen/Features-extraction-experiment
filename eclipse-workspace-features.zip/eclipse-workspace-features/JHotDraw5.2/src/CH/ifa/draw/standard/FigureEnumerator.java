/*
 * @(#)FigureEnumerator.java 5.2
 *
 */

package CH.ifa.draw.standard;

import CH.ifa.draw.framework.*;
import java.util.*;

/**
 * An Enumeration for a Vector of Figures.
 */
public final class FigureEnumerator implements FigureEnumeration {
    Iterator fEnumeration;

    public FigureEnumerator(Vector v) {
	    fEnumeration = v.iterator();
    }

    /**
     * Returns true if the enumeration contains more elements; false
     * if its empty.
     */
    public boolean hasNext() {
	    return fEnumeration.hasNext();
    }

    /**
     * Returns the next element of the enumeration. Calls to this
     * method will enumerate successive elements.
     * @exception NoSuchElementException If no more elements exist.
     */
    public Object next() {
        return fEnumeration.next();
    }

    /**
     * Returns the next element of the enumeration. Calls to this
     * method will enumerate successive elements.
     * @exception NoSuchElementException If no more elements exist.
     */
    public Figure nextFigure() {
        return (Figure)fEnumeration.next();
    }

	@Override
	public void remove() {
		// TODO Auto-generated method stub
		
	}
}
