/**
 * BSD-style license; for more info see http://pmd.sourceforge.net/license.html
 */

/**
 * Source code file used for
 * {@link net.sourceforge.pmd.cli.CLITest}
 */
public class EmptyIfStatement {
    public void foo() {
        if (1 == 2) { }
    }
}